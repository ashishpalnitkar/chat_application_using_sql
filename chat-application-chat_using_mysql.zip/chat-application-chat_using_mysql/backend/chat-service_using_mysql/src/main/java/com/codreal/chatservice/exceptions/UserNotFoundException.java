package com.codreal.chatservice.exceptions;

public class UserNotFoundException extends Throwable {
}
